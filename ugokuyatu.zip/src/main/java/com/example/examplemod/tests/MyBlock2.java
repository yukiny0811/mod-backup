package com.example.examplemod.tests;

import com.example.examplemod.ExampleMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class MyBlock2 extends Block {
    public MyBlock2() {
        super(Material.ROCK);
        setCreativeTab(ExampleMod.myCreativeTab);
        setUnlocalizedName(ExampleMod.MODID + "_myblock2");
        setRegistryName("myblock2");
    }
}
